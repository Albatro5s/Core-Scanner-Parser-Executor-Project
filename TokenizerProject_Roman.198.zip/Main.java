import java.io.IOException;

import scanner.Tokenizer;


public class Main {

	public static void main(String[] args) {

		try {
			Tokenizer tokenizer = new Tokenizer(args[0], args[1]);
			
		} catch (IOException e) {
			//check for error, print message if found
			System.out.println("ERROR: " + e.getMessage());
		}

	}

}