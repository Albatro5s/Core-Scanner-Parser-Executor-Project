CSE 3341 - 
    10:20am MWF
Tristan Roman.198

File descriptions -
scanner/...
    Tokenizer.java
        given an input file name, returns the tokenized input to the terminal
    Tokens.java
        enum of different tokens
    TokenTuple.java
        utility class which stores token type, id number, and content
Main.java
    contains the main function


Compile/Running Instructions:

    javac scanner/Tokens.java
    javac scanner/TokenTuple.java
    javac scanner/Tokenizer.java
    javac Main.java

    java Main.java [input_program] [output_file_name]

    while you need to include a String name for the output_file_name, it only creates an empty file
    (ignore for now)